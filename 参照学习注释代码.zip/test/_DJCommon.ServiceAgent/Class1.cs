﻿using System;



namespace DJCommon.ServiceAgent
{
    public class Class1
    {
    }
}
