﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace DoubleJobServer.Web
{
    //这个Program是程序的入口  asp.net core application实际就是控制台程序(console application).    它是一个调用asp.net core 相关库的console application.
    public class Program
    {
        public static void Main(string[] args)
        {
            //配置和运行程序的  Build()完之后返回一个实现了IWebHost接口的实例(WebHostBuilder), 然后调用Run()就会运行Web程序, 并且阻止这个调用的线程, 直到程序关闭.
            CreateWebHostBuilder(args).Build().Run();
        }

        //因为Logger是asp.net core 的内置service，所以我们就不需要在ConfigureService里面注册了。如果是asp.net core 1.0版本的话，我们需要配置一个或者多个Logger，但是asp.net core 2.0的话就不需要做这个工作了，因为在CreateDefaultBuilder方法里默认给配置了输出到Console和Debug窗口的Logger
        //我们的web程序需要一个宿主, 所以 BuildWebHost这个方法就创建了一个WebHostBuilder.
        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>();  //这句话表示在程序启动的时候, 我们会调用Startup这个类.
    }
}
