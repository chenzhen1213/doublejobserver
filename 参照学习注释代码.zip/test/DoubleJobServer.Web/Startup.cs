﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json.Serialization;

using NLog.Extensions.Logging;

using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;

using DoubleJobServer.Web.Services;
using DoubleJobServer.Web.Entities;

using Microsoft.EntityFrameworkCore;

namespace DoubleJobServer.Web
{
    public class Startup
    {

        public static IConfiguration Configuration { get; private set; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }


        //调用顺序: Main -> ConfigureServices -> Configure

        //Startup算是程序真正的切入点.
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        //ConfigureServices方法是用来把services(各种服务, 例如identity, ef, mvc等等包括第三方的, 或者自己写的)加入(register)到container(asp.net core的容器)中去, 并配置这些services.
        //这个container是用来进行dependency injection的(依赖注入). 所有注入的services(此外还包括一些框架已经注册好的services) 在以后写代码的时候, 都可以将它们注入(inject)进去. 例如上面的Configure方法的参数, app, env, loggerFactory都是注入进去的services.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc()// 注册MVC到Container asp.net core 2.0使用了一个大而全的metapackage, 所以这些基本的services和middleware是不需要另外安装的.
           //asp.net core 2.0 默认返回的结果格式是Json, 并使用json.net对结果默认做了camel case的转化(大概可理解为首字母小写). 
            //这一点与老.net web api 不一样, 原来的 asp.net web api 默认不适用任何NamingStrategy, 需要手动加上camelcase的转化.我很喜欢这样, 因为大多数前台框架例如angular等都约定使用camel case.
            //如果非得把这个规则去掉, 那么就在configureServices里面改一下
             .AddJsonOptions(options =>
              {
                  if (options.SerializerSettings.ContractResolver is DefaultContractResolver resolver)
                  {
                      resolver.NamingStrategy = null;
                  }
              });

            //首先，我们要把这个LocalMailService注册给Container。打开Startup.cs进入ConfigureServices方法。这里面有三种方法可以注册service：AddTransient，AddScoped和AddSingleton，这些都表示service的生命周期。
            //transient的services是每次请求（不是指Http request）都会创建一个新的实例，它比较适合轻量级的无状态的（Stateless）的service。
            //scope的services是每次http请求会创建一个实例。  singleton的在第一次请求的时候就会创建一个实例，以后也只有这一个实例，或者在ConfigureServices这段代码运行的时候创建唯一一个实例。
            //我们的LocalMailService比较适合Transient：
            //当需要IMailService的一个实现的时候，Container就会提供一个LocalMailService的实例。
#if DEBUG
            services.AddTransient<IMailService, LocalMailService>();
#else
            services.AddTransient<IMailService, CloudMailService>();
#endif



            // //需要使用这个MyContext，所以就需要先在Container中注册它，然后就可以在依赖注入中使用了
            // //使用AddDbContext这个Extension method为MyContext在Container中进行注册，它默认的生命周期使Scoped。
            // services.AddDbContext<MyContext>();

            //使用AddDbContext的另一个overload的方法，它可以带一个参数，在里面调用UseSqlServer。
            //             //关于连接字符串，我是用的是LocalDb，实例名是MSSQLLocalDB。可以在命令行查询本机LocalDb的实例，使用sqllocaldb info：
            //             var connectionString = @"Server=(localdb)\MSSQLLocalDB;Database=ProductDB;Trusted_Connection=True";
            //             services.AddDbContext<MyContext>(o => o.UseSqlServer(connectionString));


            //保存连接字符串，你可能会想到appSettings.json，但这不是一个好的想法。在本地开发的时候还没有什么问题（使用的是集成验证），但是你要部署到服务器的时候，数据库连接字符串可能包括用户名和密码（Sql Server的另一种验证方式）。加入你不小心把appSettings.json或写到C#里面的连接字符串代码提交到了Git或TFS，那么这个用户名和密码包括服务器的名称可能就被暴露了，这样做很不安全。
            //我们可以这样做，首先针对开发环境（development environment）把C#代码中的连接字符串拿掉，把它放到appSettings.json里面。然后针对正式生产环境（production environment），我们使用环境变量来保存这些敏感数据。
//            var connectionString = Configuration["connectionStrings:productionInfoDbConnectionString"];
//            services.AddDbContext<MyContext>(options => options.UseSqlServer(connectionString));
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        //Configure方法是asp.net core程序用来具体指定如何处理每个http请求的, 例如我们可以让这个程序知道我使用mvc来处理http请求, 那就调用app.UseMvc()这个方法就行. 但是目前, 所有的http请求都会导致返回"Hello World!".
        //请求管道: 那些处理http requests并返回responses的代码就组成了request pipeline(请求管道).
        //中间件: 我们可以做的就是使用一些程序来配置那些请求管道 request pipeline以便处理requests和responses.比如处理验证(authentication) 的程序, 连MVC本身就是个中间件(middleware).
        //每层中间件接到请求后都可以直接返回或者调用下一个中间件.一个比较好的例子就是: 在第一层调用authentication验证中间件, 如果验证失败, 那么直接返回一个表示请求未授权的response.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory/*, MyContext myContext*/)
        {
            //然后需要把Nlog集成到asp.net core，也就是把Nlog注册到ILoggerFactory里面。所以打开Startup.cs，首先注入ILoggerFactory，然后对ILoggerFactory进行配置，为其注册NLog的Provider
            //针对LoggerFactory.AddProvider()这种写法，Nlog一个简单的ExtensionMethod做了这个工作，就是AddNlog();
            // loggerFactory.AddProvider(new NLogLoggerProvider());
            loggerFactory.AddNLog();



            //ASP.NET Core控制环境切换最核心的东西是“ASPNETCORE_ENVIRONMENT”环境变量，它直接控制当前应用程序运行的环境类型。您可以通过在项目上右键菜单选择“属性”选项，然后切换到“调试”标签来修改此环境变量。
　　       //此环境变量框架默认提供了三个值，当然您也可以定义其它的值：  Development（开发）   | Staging（预演） |Production（生产）
            if (env.IsDevelopment())   //而判断env.isDevelopment() 表示, 这个middleware只会在Development环境下被调用
            {
                app.UseDeveloperExceptionPage(); //就是一个middleware, 当exception发生的时候, 这段程序就会处理它. . UseExceptionHandler是可以传参数的
            }
            else
            {
                app.UseExceptionHandler("/error"); //在正式环境中, 我们遇到exception的时候, 需要捕获并把它记录(log)下来, 这时候我们应该使用这个middleware: Exception Handler Middleware
            }

            //             app.Run(async (context) =>
            //             {
            //                 await context.Response.WriteAsync("Hello World!");
            //             });

            //这是个Extension method，如果数据库没有数据，那就弄点种子数据，AddRange可以添加批量数据到Context（被Context追踪），但是到这还没有插入到数据库。使用SaveChanges会把数据保存到数据库。
            //myContext.EnsureSeedDataForContext();

            app.UseStatusCodePages();

            app.UseMvc(); //告诉程序使用mvc中间件

        }
    }
}
