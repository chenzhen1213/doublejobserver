﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System.Diagnostics;

using Microsoft.Extensions.Logging;

namespace DoubleJobServer.Web.Services
{
    //有了IMailService这个interface，Container就可以为我们提供实现了IMailService接口的不同的类了
    public interface IMailService
    {
        void Send(string subject, string msg);
    }

    public class LocalMailService : IMailService
    {

        //通过刚才写的Startup.Configuration来访问json配置文件中的变量，根据json文件中的层次结构，第一层对象我们取的是mailSettings，然后试mailToAddress和mailFromAddress，他们之间用冒号分开，表示它们的层次结构。 通过这种方法取得到的值都是字符串
        private readonly string _mailTo = Startup.Configuration["mailSettings:mailToAddress"];
        private readonly string _mailFrom = Startup.Configuration["mailSettings:mailFromAddress"];
        
        public void Send(string subject, string msg)
        {
            Debug.WriteLine($"从{_mailFrom}给{_mailTo}通过{nameof(LocalMailService)}发送了邮件");
        }
    }

    public class CloudMailService : IMailService
    {
        private readonly string _mailTo = "admin@qq.com";
        private readonly string _mailFrom = "noreply@alibaba.com";

        private readonly ILogger<CloudMailService> _logger;
        public CloudMailService(ILogger<CloudMailService> logger)
        {
            _logger = logger;
        }


        public void Send(string subject, string msg)
        {
            Debug.WriteLine($"从{_mailFrom}给{_mailTo}通过{nameof(LocalMailService)}发送了邮件");
        }
    }
}

