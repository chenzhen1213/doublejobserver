﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace DoubleJobServer.Web.Entities
{

    //Entity就是普通的C#类，就像Dto一样。Dto是与外界打交道的Model，entity则不一样，有一些Dto的计算属性我们并不像保存在数据库中，所以entity中没有这些属性；而数据从entity传递到Dto后某些属性也会和数据库里面的形式不一样
    public class Product
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public float Price { get; set; }
        public string Description { get; set; }
    }

    //EFCore使用一个DbContext和数据库打交道，它代表着和数据库之间的一个Session，可以用来查询和保存我们的entities。 DbContext需要一个Provider，以便能访问数据库（这里我们就用LocalDB吧）。
    //就建立一个DbContext吧（大一点的项目会使用多个DbContext）。建立MyContext并集成DbContext
    //这里我们为Product建立了一个类型为DbSet<T>的属性，它可以用来查询和保存实例（针对DbSet的Linq查询语句将会被解释成针对数据库的查询语句）。
    public class MyContext : DbContext
    {
        //DbContext的源码的定义,有一个Constructor带有一个DbContextOptions参数，那我们就在MyContext种建立一个Constructor，并overload这个带有参数的Constructor。
        //它可以在我们注册MyContext的时候就提供options，显然这样做比第一种override OnConfiguring更合理。
        public MyContext(DbContextOptions<MyContext> options)
           : base(options)
        {
            //这个Constructor在被依赖注入的时候会被调用，在里面写Database.EnsureCreated()。其中Database是DbContext的一个属性对象。EnsureCreated()的作用是，如果有数据库存在，那么什么也不会发生。但是如果没有，那么就会创建一个数据库。
            //但是现在就运行的话，并不会创建数据库，因为没有创建MyContext的实例，也就不会调用Constructor里面的内容。那我们就建立一个临时的Controller，然后注入MyContext，此时就调用了MyContext的Constructor：
            //Database.EnsureCreated()确实可以保证创建数据库，但是随着代码不断被编写，我们的Model不断再改变，数据库应该也随之改变，而EnsureCreated()就不够了，这就需要迁移（Migration）。

           //Database.EnsureCreated();
           //Database.Migrate();
        }

        public DbSet<Product> Products { get; set; }

        //其中的参数optionsBuilder提供了一个UseSqlServer()这个方法，它告诉Dbcontext将会被用来连接Sql Server数据库，在这里就可以提供连接字符串，这就是第一种方法。
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("xxxx connection string");
            base.OnConfiguring(optionsBuilder);
        }

        //针对Product这个entity，我们要把它映射成一个数据库的表，所以针对每个属性，可能需要设定一些限制，例如最大长度，是否必填等等。
        // 针对Product，我们可以在MyContext里面override OnModelCreating这个方法

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new ProductConfiguration());
        }
    }

    //但是项目中如果有很多entities的话也需要写很多行代码，更好的做法是写一个方法，可以加载所有实现了IEntityTypeConfiguration<T>的实现类。在老版的asp.net web api 2.2里面有一个方法可以从某个Assembly加载所有继承于EntityTypeConfiguration的类，但是entity framework core并没有提供类似的方法，以后我们自己写一个吧，现在先这样。
    public class ProductConfiguration : IEntityTypeConfiguration<Product>
    {
        public void Configure(EntityTypeBuilder<Product> builder)
        {
            //第一行表示设置Id为主键（其实我们并不需要这么做）。然后Name属性是必填的，而且最大长度是50。最后Price的精度是8，2，数据库里的类型为decimal。  fluent api有很多方法
            builder.HasKey(x => x.Id);
            builder.Property(x => x.Name).IsRequired().HasMaxLength(50);
            builder.Property(x => x.Price).HasColumnType("decimal(8,2)");

            builder.Property(x => x.Description).HasMaxLength(200);
        }
    }
}
