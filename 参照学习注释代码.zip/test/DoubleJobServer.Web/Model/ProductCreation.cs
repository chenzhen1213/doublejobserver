﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;      //在开发ASP.NET Core MVC应用程序时，需要对控制器中的模型校验数据有效性，元数据注释(Data Annotations)是一个完美的解决方案。

//但是这种通过注解的验证方式把验证的代码和Model的代码混到了一起, 并不是很好的Separationg of Concern, 而且同时在Model和Controller里面为Model写验证相关的代码也不太好. 
//这是方式是asp.net core 内置的, 所以简单的情况下还是可以用的.如果需求比较复杂, 可以使用FluentValidation, 以后会加入这个库.

namespace CoreBackend.Api.Dtos
{
    //验证Model/实体, asp.net core 内置可以使用 Data Annotations进行
    public class ProductCreation
    {
        //这些Data Annotation (理解为用于验证的注解), 可以在System.ComponentModel.DataAnnotation找到, 例如[Required]表示必填, [MinLength]表示最小长度, [StringLength]可以同时验证最小和最大长度, [Range]表示数值的范围等等很多.
        //其他的验证注解都有一个属性叫做ErrorMessage(string), 表示如果验证失败, 就会把ErrorMessage的内容添加到错误结果里面去.这个ErrorMessage可以使用参数, {0}表示Display的Name属性, {1}表示当前注解的第一个变量, {2}表示当前注解的第二个变量.

        [Display(Name = "产品名称")]  //给属性起一个比较友好的名字.
        [Required(ErrorMessage = "{0}是必填项")]
        // [MinLength(2, ErrorMessage = "{0}的最小长度是{1}")]
        // [MaxLength(10, ErrorMessage = "{0}的长度不可以超过{1}")]
        [StringLength(10, MinimumLength = 2, ErrorMessage = "{0}的长度应该不小于{2}, 不大于{1}")]
        public string Name { get; set; }

        [Display(Name = "价格")]
        [Range(0, Double.MaxValue, ErrorMessage = "{0}的值必须大于{1}")]
        public float Price { get; set; }

        
        [Display(Name = "描述")]
        [MaxLength(100, ErrorMessage = "{0}的长度不可以超过{1}")]
        public string Description { get; set; }
    }
}
