﻿using System;

namespace DoubleJobServer.Swagger
{
    public class Class1
    {
    }
}
